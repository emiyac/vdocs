import{_ as n,a,o as l,a3 as e}from"./chunks/framework.dRMRuUHH.js";const u=JSON.parse('{"title":"nginx配置详解","description":"","frontmatter":{"id":2002,"title":"nginx配置详解","createTime":"2024-02-04 17:41:14","category":"middleware"},"headers":[],"relativePath":"docs/middleware/nginx/at2kf0f2b3yo.md","filePath":"docs/middleware/nginx/00102_nginx_config.md"}'),p={name:"docs/middleware/nginx/at2kf0f2b3yo.md"};function r(o,s,t,c,i,b){return l(),a("div",null,[...s[0]||(s[0]=[e(`<p>👉<a href="https://nginx.org/en/docs/" target="_blank" rel="noreferrer">nginx官方文档</a></p><h2 id="nginx配置文件结构" tabindex="-1">nginx配置文件结构 <a class="header-anchor" href="#nginx配置文件结构" aria-label="Permalink to “nginx配置文件结构”">​</a></h2><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#88846F;"># main块</span></span>
<span class="line"><span style="color:#66D9EF;">...</span></span>
<span class="line"></span>
<span class="line"><span style="color:#88846F;"># events块</span></span>
<span class="line"><span style="color:#A6E22E;">events</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#66D9EF;">    ...</span></span>
<span class="line"><span style="color:#F8F8F2;">}</span></span>
<span class="line"></span>
<span class="line"><span style="color:#88846F;"># mail块</span></span>
<span class="line"><span style="color:#A6E22E;">mail</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#66D9EF;">    ...</span></span>
<span class="line"><span style="color:#88846F;">    # server块</span></span>
<span class="line"><span style="color:#A6E22E;">    server</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#66D9EF;">        ...</span></span>
<span class="line"><span style="color:#F8F8F2;">    }</span></span>
<span class="line"><span style="color:#F8F8F2;">}</span></span>
<span class="line"></span>
<span class="line"><span style="color:#88846F;"># stream块</span></span>
<span class="line"><span style="color:#A6E22E;">stream</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#66D9EF;">    ...</span></span>
<span class="line"><span style="color:#88846F;">    # upstream块, 可以有多个</span></span>
<span class="line"><span style="color:#A6E22E;">    upstream</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#66D9EF;">        ....</span></span>
<span class="line"><span style="color:#F8F8F2;">    }</span></span>
<span class="line"><span style="color:#88846F;">    # server块, 可以有多个</span></span>
<span class="line"><span style="color:#A6E22E;">    server</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#66D9EF;">        ...</span></span>
<span class="line"><span style="color:#F8F8F2;">    }</span></span>
<span class="line"><span style="color:#F8F8F2;">}</span></span>
<span class="line"></span>
<span class="line"><span style="color:#88846F;"># http块</span></span>
<span class="line"><span style="color:#A6E22E;">http</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#66D9EF;">    ...</span></span>
<span class="line"><span style="color:#88846F;">    # upstream块, 可以有多个</span></span>
<span class="line"><span style="color:#A6E22E;">    upstream</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#66D9EF;">        ...</span></span>
<span class="line"><span style="color:#F8F8F2;">    }</span></span>
<span class="line"><span style="color:#88846F;">    # server块, 可以有多个</span></span>
<span class="line"><span style="color:#A6E22E;">    server</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#66D9EF;">        ...</span></span>
<span class="line"><span style="color:#88846F;">        # location块, 可以有多个</span></span>
<span class="line"><span style="color:#A6E22E;">        location</span><span style="color:#F8F8F2;"> [pattern] {</span></span>
<span class="line"><span style="color:#66D9EF;">            ...</span></span>
<span class="line"><span style="color:#F8F8F2;">        }</span></span>
<span class="line"><span style="color:#F8F8F2;">    }</span></span>
<span class="line"><span style="color:#F8F8F2;">}</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br><span class="line-number">9</span><br><span class="line-number">10</span><br><span class="line-number">11</span><br><span class="line-number">12</span><br><span class="line-number">13</span><br><span class="line-number">14</span><br><span class="line-number">15</span><br><span class="line-number">16</span><br><span class="line-number">17</span><br><span class="line-number">18</span><br><span class="line-number">19</span><br><span class="line-number">20</span><br><span class="line-number">21</span><br><span class="line-number">22</span><br><span class="line-number">23</span><br><span class="line-number">24</span><br><span class="line-number">25</span><br><span class="line-number">26</span><br><span class="line-number">27</span><br><span class="line-number">28</span><br><span class="line-number">29</span><br><span class="line-number">30</span><br><span class="line-number">31</span><br><span class="line-number">32</span><br><span class="line-number">33</span><br><span class="line-number">34</span><br><span class="line-number">35</span><br><span class="line-number">36</span><br><span class="line-number">37</span><br><span class="line-number">38</span><br><span class="line-number">39</span><br><span class="line-number">40</span><br><span class="line-number">41</span><br><span class="line-number">42</span><br><span class="line-number">43</span><br><span class="line-number">44</span><br><span class="line-number">45</span><br><span class="line-number">46</span><br></div></div><ul><li>main：提供了<code>nginx</code>服务运行的基本功能, 包括进程管理、<code>cpu</code>亲缘性、内存管理、配置文件解析、日志管理等</li><li>events块：负责进行连接处理, 提供对不同操作系统的<code>I/O</code>网络模型支持， 自动根据操作系统选择最有效的<code>I/O</code>网络模型。</li><li>mail块：提供邮件代理功能 <ul><li>server</li></ul></li><li>stream块：提供<code>tcp</code>和<code>udp</code>会话的代理和负载相关功能 <ul><li>upstream</li><li>server</li></ul></li><li>http块：提供<code>http</code>处理的核心功能和部分功能模块 <ul><li>upstream</li><li>server <ul><li>location</li></ul></li></ul></li></ul><h2 id="nginx常用变量" tabindex="-1">nginx常用变量 <a class="header-anchor" href="#nginx常用变量" aria-label="Permalink to “nginx常用变量”">​</a></h2><table tabindex="0"><thead><tr><th style="text-align:left;">变量名</th><th style="text-align:left;">功能</th></tr></thead><tbody><tr><td style="text-align:left;"><code>$arg_</code></td><td style="text-align:left;">获取指定请求参数的值, 例如<code>?key=100</code>, <code>$arg_key=100</code></td></tr><tr><td style="text-align:left;"><code>$args</code></td><td style="text-align:left;">获取所有的请求参数</td></tr><tr><td style="text-align:left;"><code>$connection</code></td><td style="text-align:left;">连接的序列号</td></tr><tr><td style="text-align:left;"><code>$connection_requests</code></td><td style="text-align:left;">当前连接数</td></tr><tr><td style="text-align:left;"><code>$connection_time</code></td><td style="text-align:left;">建立连接的时间(单位秒)</td></tr><tr><td style="text-align:left;"><code>$content_length</code></td><td style="text-align:left;">请求头的<code>Content-Length</code>字段</td></tr><tr><td style="text-align:left;"><code>$content_type</code></td><td style="text-align:left;">请求头的<code>Content-Type</code>字段</td></tr><tr><td style="text-align:left;"><code>$host</code></td><td style="text-align:left;">依次获取请求信息中的主机名、请求头中的<code>host</code>字段、与请求匹配的服务器名; 不包含端口</td></tr><tr><td style="text-align:left;"><code>$http_</code></td><td style="text-align:left;">获取http相关的信息; 例如<code>$http_user_agent</code>, <code>$http_cookie</code></td></tr><tr><td style="text-align:left;"><code>$remote_addr</code></td><td style="text-align:left;">客户端ip</td></tr><tr><td style="text-align:left;"><code>$remote_port</code></td><td style="text-align:left;">客户端端口</td></tr><tr><td style="text-align:left;"><code>$request</code></td><td style="text-align:left;">完整的原始请求, 例如<code>POST /t01?cname=tom&amp;age=12 HTTP/1.1</code></td></tr><tr><td style="text-align:left;"><code>$request_length</code></td><td style="text-align:left;">请求长度, 包括请求路径、请求头、请求体</td></tr><tr><td style="text-align:left;"><code>$request_method</code></td><td style="text-align:left;">请求方法</td></tr><tr><td style="text-align:left;"><code>$request_time</code></td><td style="text-align:left;">请求处理时间(单位: 秒), 包括<code>nginx</code>服务从发起请求的客户端获取到第一个字节开始，到返回给客户端最后一个字节后经过的时间</td></tr><tr><td style="text-align:left;"><code>$request_uri</code></td><td style="text-align:left;">带参数的完整的uri; 例如 <code>/t01?cname=tom&amp;age=12</code></td></tr><tr><td style="text-align:left;"><code>$scheme</code></td><td style="text-align:left;">请求协议</td></tr><tr><td style="text-align:left;"><code>$upstream_addr</code></td><td style="text-align:left;"><code>nginx</code>转发给后端服务节点的地址, 即真正处理请求的服务器地址</td></tr><tr><td style="text-align:left;"><code>$upstream_bytes_received</code></td><td style="text-align:left;">从后端服务器收到的字节数</td></tr><tr><td style="text-align:left;"><code>$upstream_bytes_sent</code></td><td style="text-align:left;">发送给后端服务器的字节数</td></tr><tr><td style="text-align:left;"><code>$upstream_connect_time</code></td><td style="text-align:left;">和后端服务器建立连接的时间, 如果用到加密协议还包括握手时间</td></tr><tr><td style="text-align:left;"><code>$upstream_header_time</code></td><td style="text-align:left;">从后端服务器接收响应头的时间, 包括和后端服务器建立连接的时间, 到接收完响应头的时间</td></tr><tr><td style="text-align:left;"><code>$upstream_response_length</code></td><td style="text-align:left;">从后端服务器接收响应的长度</td></tr><tr><td style="text-align:left;"><code>$upstream_response_time</code></td><td style="text-align:left;">从后端服务器接收响应的时间, 包括和后端服务器建立连接的时间, 接收到响应头的时间, 和接收完响应体的时间</td></tr><tr><td style="text-align:left;"><code>$upstream_status</code></td><td style="text-align:left;">从后端服务器接收的状态码</td></tr><tr><td style="text-align:left;"><code>$upstream_http_</code></td><td style="text-align:left;">从后端服务器接收响应头的值, 例如<code>upstream_http_content_type</code></td></tr></tbody></table><h2 id="main" tabindex="-1">main <a class="header-anchor" href="#main" aria-label="Permalink to “main”">​</a></h2><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#88846F;"># 指定运行nginx服务的用户和组, </span></span>
<span class="line"><span style="color:#88846F;"># syntax:	user user [group];</span></span>
<span class="line"><span style="color:#88846F;"># default:	user nobody nobody;</span></span>
<span class="line"><span style="color:#88846F;"># context:	main</span></span>
<span class="line"><span style="color:#A6E22E;">user</span><span style="color:#E6DB74;"> nginx</span><span style="color:#E6DB74;"> nginx</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#88846F;"># 指定工作进程数, 可以指定具体的进程数, 也可以auto自动设置</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	worker_processes number | auto;</span></span>
<span class="line"><span style="color:#88846F;"># default:	worker_processes 1;</span></span>
<span class="line"><span style="color:#88846F;"># context:	main</span></span>
<span class="line"><span style="color:#A6E22E;">worker_processes</span><span style="color:#AE81FF;"> 4</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#88846F;"># 指定单个进程最大能够打开的文件数量, 即文件描述符数</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	worker_rlimit_nofile number;</span></span>
<span class="line"><span style="color:#88846F;"># default:	默认值与当前linux系统中进程可以打开的最大文件数量相同</span></span>
<span class="line"><span style="color:#88846F;"># context:	main</span></span>
<span class="line"><span style="color:#A6E22E;">worker_rlimit_nofile</span><span style="color:#AE81FF;"> 65536</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#88846F;"># 指定pid文件位置, 该指令只能在全局块配置</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	pid file;</span></span>
<span class="line"><span style="color:#88846F;"># default:	pid logs/nginx.pid;</span></span>
<span class="line"><span style="color:#88846F;"># context:	main</span></span>
<span class="line"><span style="color:#A6E22E;">pid</span><span style="color:#E6DB74;"> /var/run/nginx.pid</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#88846F;"># 用来包含其他的配置文件, 此处用来指定媒体类型配置文件</span></span>
<span class="line"><span style="color:#88846F;"># syntax:   include file;</span></span>
<span class="line"><span style="color:#88846F;"># context:  main, http, mail, stream, server, location</span></span>
<span class="line"><span style="color:#A6E22E;">include</span><span style="color:#E6DB74;"> mime.types</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#88846F;"># 对于无扩展名的文件, 默认其为application/octet-stream类型, 即nginx会将其作为一个八进制流文件来处理</span></span>
<span class="line"><span style="color:#88846F;"># module:   ngx_http_core_module</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	default_type mime-type;</span></span>
<span class="line"><span style="color:#88846F;"># default:	default_type text/plain;</span></span>
<span class="line"><span style="color:#88846F;"># context:	http, server, location</span></span>
<span class="line"><span style="color:#A6E22E;">default_type</span><span style="color:#E6DB74;"> application/octet-stream</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#88846F;"># 是否开启linux系统的零拷贝机制, 当然还需要当前操作系统支持</span></span>
<span class="line"><span style="color:#88846F;"># module:   ngx_http_core_module</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	sendfile on | off;</span></span>
<span class="line"><span style="color:#88846F;"># default:	sendfile off;</span></span>
<span class="line"><span style="color:#88846F;"># context:	http, server, location</span></span>
<span class="line"><span style="color:#A6E22E;">sendfile</span><span style="color:#E6DB74;"> on</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#88846F;"># 当开启该指令是会调用操作系统的tcp_cork方法, 即在一定的时间段(通常为200ms), 将小数据包暂存, 并将这些小数据包整合为一个大的数据包后发送出去, 可以一定程度的改善网络传输效率</span></span>
<span class="line"><span style="color:#88846F;"># 当开启sendfile指令时tcp_nopush才会生效, 且和tcp_nodelay指令互斥</span></span>
<span class="line"><span style="color:#88846F;"># module:   ngx_http_core_module</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	tcp_nopush on | off;</span></span>
<span class="line"><span style="color:#88846F;"># default:	tcp_nopush off;</span></span>
<span class="line"><span style="color:#88846F;"># context:	http, server, location</span></span>
<span class="line"><span style="color:#A6E22E;">tcp_nopush</span><span style="color:#E6DB74;"> off</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#88846F;"># 开启后会禁用tcp_nopush指令, 且在nginx开启长连接才会生效, 即收到数据包后尽快发送出去</span></span>
<span class="line"><span style="color:#88846F;"># module:   ngx_http_core_module</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	tcp_nodelay on | off;</span></span>
<span class="line"><span style="color:#88846F;"># default:	tcp_nodelay on;</span></span>
<span class="line"><span style="color:#88846F;"># context:	http, server, location</span></span>
<span class="line"><span style="color:#A6E22E;">tcp_nodelay</span><span style="color:#E6DB74;"> off</span><span style="color:#F8F8F2;">;</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br><span class="line-number">9</span><br><span class="line-number">10</span><br><span class="line-number">11</span><br><span class="line-number">12</span><br><span class="line-number">13</span><br><span class="line-number">14</span><br><span class="line-number">15</span><br><span class="line-number">16</span><br><span class="line-number">17</span><br><span class="line-number">18</span><br><span class="line-number">19</span><br><span class="line-number">20</span><br><span class="line-number">21</span><br><span class="line-number">22</span><br><span class="line-number">23</span><br><span class="line-number">24</span><br><span class="line-number">25</span><br><span class="line-number">26</span><br><span class="line-number">27</span><br><span class="line-number">28</span><br><span class="line-number">29</span><br><span class="line-number">30</span><br><span class="line-number">31</span><br><span class="line-number">32</span><br><span class="line-number">33</span><br><span class="line-number">34</span><br><span class="line-number">35</span><br><span class="line-number">36</span><br><span class="line-number">37</span><br><span class="line-number">38</span><br><span class="line-number">39</span><br><span class="line-number">40</span><br><span class="line-number">41</span><br><span class="line-number">42</span><br><span class="line-number">43</span><br><span class="line-number">44</span><br><span class="line-number">45</span><br><span class="line-number">46</span><br><span class="line-number">47</span><br><span class="line-number">48</span><br><span class="line-number">49</span><br><span class="line-number">50</span><br><span class="line-number">51</span><br><span class="line-number">52</span><br><span class="line-number">53</span><br><span class="line-number">54</span><br><span class="line-number">55</span><br><span class="line-number">56</span><br><span class="line-number">57</span><br></div></div><h2 id="events" tabindex="-1">events <a class="header-anchor" href="#events" aria-label="Permalink to “events”">​</a></h2><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#A6E22E;">events</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#88846F;">    # 对nginx工作进程接收连接序列化, 防止多个工作进程对连接进行争抢(当客户端发来一个请求时, 会有多个nginx工作进程被同时唤醒, 即使最终只有一个工作进程会获得连接, 且其他工作进程会进入阻塞状态, 如果每次唤醒的工作进程过多, 就会影响nginx的整体性能)</span></span>
<span class="line"><span style="color:#88846F;">    # syntax:	accept_mutex on | off;</span></span>
<span class="line"><span style="color:#88846F;">    # default:	accept_mutex off;</span></span>
<span class="line"><span style="color:#88846F;">    # context:	events</span></span>
<span class="line"><span style="color:#A6E22E;">    accept_mutex</span><span style="color:#E6DB74;"> on</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#88846F;">    # 设置单个nginx工作进程是否允许同时接收多个网络连接</span></span>
<span class="line"><span style="color:#88846F;">    # syntax:	multi_accept on | off;</span></span>
<span class="line"><span style="color:#88846F;">    # default:	multi_accept off;</span></span>
<span class="line"><span style="color:#88846F;">    # context:	events</span></span>
<span class="line"><span style="color:#A6E22E;">    multi_accept</span><span style="color:#E6DB74;"> on</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#88846F;">    # 设置I/O事件驱动模型</span></span>
<span class="line"><span style="color:#88846F;">    # syntax:   use  [method];</span></span>
<span class="line"><span style="color:#88846F;">    ## method:  [select | poll | kqueue | epoll | resig | /dev/poll | eventport]</span></span>
<span class="line"><span style="color:#88846F;">    # default:  选择当前操作系统支持的事件驱动模型</span></span>
<span class="line"><span style="color:#88846F;">    # context:  events</span></span>
<span class="line"><span style="color:#A6E22E;">    use</span><span style="color:#E6DB74;"> epoll</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#88846F;">    # 设置单个nginx工作进程可以同时开启的最大连接数, 当超过这个值时将不在接收连接</span></span>
<span class="line"><span style="color:#88846F;">    # syntax: worker_connections number;</span></span>
<span class="line"><span style="color:#88846F;">    # default: worker_connections 512;</span></span>
<span class="line"><span style="color:#88846F;">    # context: events</span></span>
<span class="line"><span style="color:#A6E22E;">    worker_connections</span><span style="color:#AE81FF;"> 1024</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">}</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br><span class="line-number">9</span><br><span class="line-number">10</span><br><span class="line-number">11</span><br><span class="line-number">12</span><br><span class="line-number">13</span><br><span class="line-number">14</span><br><span class="line-number">15</span><br><span class="line-number">16</span><br><span class="line-number">17</span><br><span class="line-number">18</span><br><span class="line-number">19</span><br><span class="line-number">20</span><br><span class="line-number">21</span><br><span class="line-number">22</span><br><span class="line-number">23</span><br><span class="line-number">24</span><br><span class="line-number">25</span><br><span class="line-number">26</span><br></div></div><h2 id="http七层代理" tabindex="-1">http七层代理 <a class="header-anchor" href="#http七层代理" aria-label="Permalink to “http七层代理”">​</a></h2><h3 id="upstream" tabindex="-1">upstream <a class="header-anchor" href="#upstream" aria-label="Permalink to “upstream”">​</a></h3><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#88846F;"># 用于定义可以由proxy_pass指令引用的服务器组, 可以指定服务节点的地址和相关的参数, 服务器地址可以是带端口的域名或者ip地址、unix套接字路径, 参数可以设置服务权重、健康检查等</span></span>
<span class="line"><span style="color:#88846F;"># module: ngx_http_upstream_module</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	server address [parameters];</span></span>
<span class="line"><span style="color:#88846F;"># default:	—</span></span>
<span class="line"><span style="color:#88846F;"># context:	http</span></span>
<span class="line"><span style="color:#A6E22E;">upstream</span><span style="color:#E6DB74;"> backend</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#A6E22E;">    server</span><span style="color:#E6DB74;"> 192.168.10.100:8080</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    server</span><span style="color:#E6DB74;"> ep01.example.com:8081</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    server</span><span style="color:#E6DB74;"> unix:/opt/app/uwsgi.sock</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">    </span></span>
<span class="line"><span style="color:#88846F;">    # 设置服务节点的权重</span></span>
<span class="line"><span style="color:#88846F;">    # syntax:	server address weight=number;</span></span>
<span class="line"><span style="color:#A6E22E;">    server</span><span style="color:#E6DB74;"> 192.168.10.101:8080</span><span style="color:#E6DB74;"> weight=</span><span style="color:#AE81FF;">2</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">    </span></span>
<span class="line"><span style="color:#88846F;">    # 设置同时连接到该服务节点的最大连接数, 限制流量</span></span>
<span class="line"><span style="color:#88846F;">    # syntax:	server address max_conns=number;</span></span>
<span class="line"><span style="color:#A6E22E;">    server</span><span style="color:#E6DB74;"> 192.168.10.102:8080</span><span style="color:#E6DB74;"> max_conns=</span><span style="color:#AE81FF;">10</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">    </span></span>
<span class="line"><span style="color:#88846F;">    # 在fail_timeout时间内与服务尝试通信失败max_fails次, 则视为服务不可用且流量不会转发到该服务节点上;如果只有一个服务节点将忽略该参数</span></span>
<span class="line"><span style="color:#88846F;">    # syntax:	server address max_fails=number fail_timeout=time; </span></span>
<span class="line"><span style="color:#A6E22E;">    server</span><span style="color:#E6DB74;"> 192.168.10.103:8080</span><span style="color:#E6DB74;"> max_fails=</span><span style="color:#AE81FF;">3</span><span style="color:#E6DB74;"> fail_timeout=</span><span style="color:#AE81FF;">10</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">    </span></span>
<span class="line"><span style="color:#88846F;">    # 标记当前服务节点为备用节点, 当主服务节点不可用时, 该节点才会接收连接处理请求注意该参数不能与hash和random一起使用</span></span>
<span class="line"><span style="color:#88846F;">    # syntax:	server address backup;</span></span>
<span class="line"><span style="color:#A6E22E;">    server</span><span style="color:#E6DB74;"> 192.168.10.104:8080</span><span style="color:#E6DB74;"> backup</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">    </span></span>
<span class="line"><span style="color:#88846F;">    # 用于标记节点为不可用</span></span>
<span class="line"><span style="color:#88846F;">    # syntax:	server address down;</span></span>
<span class="line"><span style="color:#A6E22E;">    server</span><span style="color:#E6DB74;"> 192.168.10.101:8080</span><span style="color:#E6DB74;"> down</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">    </span></span>
<span class="line"><span style="color:#88846F;">    # 设置服务节点从权重从0恢复到正常值的时间; 注意该参数不能用在只有一个服务节点或者使用hash、random负载模式下</span></span>
<span class="line"><span style="color:#88846F;">    # syntax:	server address slow_start=time;</span></span>
<span class="line"><span style="color:#A6E22E;">    server</span><span style="color:#E6DB74;"> 192.168.10.101:8080</span><span style="color:#E6DB74;"> weight=</span><span style="color:#AE81FF;">4</span><span style="color:#E6DB74;"> slow_start=</span><span style="color:#AE81FF;">60</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">}</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br><span class="line-number">9</span><br><span class="line-number">10</span><br><span class="line-number">11</span><br><span class="line-number">12</span><br><span class="line-number">13</span><br><span class="line-number">14</span><br><span class="line-number">15</span><br><span class="line-number">16</span><br><span class="line-number">17</span><br><span class="line-number">18</span><br><span class="line-number">19</span><br><span class="line-number">20</span><br><span class="line-number">21</span><br><span class="line-number">22</span><br><span class="line-number">23</span><br><span class="line-number">24</span><br><span class="line-number">25</span><br><span class="line-number">26</span><br><span class="line-number">27</span><br><span class="line-number">28</span><br><span class="line-number">29</span><br><span class="line-number">30</span><br><span class="line-number">31</span><br><span class="line-number">32</span><br><span class="line-number">33</span><br><span class="line-number">34</span><br></div></div><h3 id="server" tabindex="-1">server <a class="header-anchor" href="#server" aria-label="Permalink to “server”">​</a></h3><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#88846F;"># 用来配置虚拟主机, 即每一个server块就是一个虚拟主机</span></span>
<span class="line"><span style="color:#88846F;"># module: ngx_http_core_module</span></span>
<span class="line"></span>
<span class="line"><span style="color:#88846F;"># syntax:	server { ... }</span></span>
<span class="line"><span style="color:#88846F;"># default:	—</span></span>
<span class="line"><span style="color:#88846F;"># context:	http</span></span>
<span class="line"><span style="color:#A6E22E;">server</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#88846F;">    # 设置nginx服务器监听的地址和端口</span></span>
<span class="line"><span style="color:#88846F;">    # 没有显示的申明default_server是, nginx会将配置的第一个server作为default_server</span></span>
<span class="line"><span style="color:#88846F;">    # 当请求没有匹配到任何server_name时,default_server会处理该请求</span></span>
<span class="line"><span style="color:#88846F;">    # syntax:	listen port [default_server] [ssl] [http2 | quic];</span></span>
<span class="line"><span style="color:#88846F;">    # default:	listen *:80 | *:8000;</span></span>
<span class="line"><span style="color:#88846F;">    # context:	server</span></span>
<span class="line"><span style="color:#A6E22E;">    listen</span><span style="color:#AE81FF;"> 80</span><span style="color:#E6DB74;"> default_server</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    listen</span><span style="color:#F8F8F2;"> [::]:80;</span></span>
<span class="line"><span style="color:#F8F8F2;">    </span></span>
<span class="line"><span style="color:#88846F;">    # 为虚拟主机设置名称, 可以配置多个server_name, 可以使用通配符, 正则表达式等</span></span>
<span class="line"><span style="color:#88846F;">    # 匹配规则: 依次按照精确匹配、以*通配符开始的最长字符串匹配、以*通配符结束的最长字符串匹配、第一个匹配的正则表达式</span></span>
<span class="line"><span style="color:#88846F;">    # syntax:	server_name name ...;</span></span>
<span class="line"><span style="color:#88846F;">    # default:	server_name &quot;&quot;;</span></span>
<span class="line"><span style="color:#88846F;">    # context:	server</span></span>
<span class="line"><span style="color:#A6E22E;">    server_name</span><span style="color:#E6DB74;"> www.example.com</span><span style="color:#E6DB74;"> bbs.example.com</span><span style="color:#E6DB74;"> .example.com</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    server_name</span><span style="color:#FD971F;"> *</span><span style="color:#E6DB74;">.example.com</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    server_name</span><span style="color:#E6DB74;"> www.example.</span><span style="color:#FD971F;">*</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    server_name</span><span style="color:#E6DB74;"> www</span><span style="color:#AE81FF;">\\d</span><span style="color:#E6DB74;">+</span><span style="color:#AE81FF;">\\.</span><span style="color:#E6DB74;">example</span><span style="color:#AE81FF;">\\.</span><span style="color:#E6DB74;">com</span><span style="color:#F8F8F2;">$;</span></span>
<span class="line"><span style="color:#A6E22E;">    server_name</span><span style="color:#E6DB74;"> _</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">    </span></span>
<span class="line"><span style="color:#88846F;">    # 是否开启在响应头中显示nginx服务器版本</span></span>
<span class="line"><span style="color:#88846F;">    # syntax:	server_tokens on | off | build;</span></span>
<span class="line"><span style="color:#88846F;">    # default:	server_tokens on;</span></span>
<span class="line"><span style="color:#88846F;">    # context:	http, server, location</span></span>
<span class="line"><span style="color:#A6E22E;">    server_tokens</span><span style="color:#E6DB74;"> off</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">    </span></span>
<span class="line"><span style="color:#88846F;">    # 添加响应头</span></span>
<span class="line"><span style="color:#88846F;">    # module:   ngx_http_headers_module</span></span>
<span class="line"><span style="color:#88846F;">    # syntax:	add_header name value [always];</span></span>
<span class="line"><span style="color:#88846F;">    # default:	—</span></span>
<span class="line"><span style="color:#88846F;">    # context:	http, server, location</span></span>
<span class="line"><span style="color:#88846F;">    # 添加响应头解决跨域问题</span></span>
<span class="line"><span style="color:#A6E22E;">    add_header</span><span style="color:#E6DB74;"> &#39;Access-Control-Allow-Origin&#39;</span><span style="color:#F8F8F2;"> $http_origin;</span></span>
<span class="line"><span style="color:#A6E22E;">    add_header</span><span style="color:#E6DB74;"> &#39;Access-Control-Allow-Credentials&#39;</span><span style="color:#E6DB74;"> &#39;true&#39;</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    add_header</span><span style="color:#E6DB74;"> &#39;Access-Control-Allow-Methods&#39;</span><span style="color:#E6DB74;"> &#39;GET, POST, OPTIONS&#39;</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    add_header</span><span style="color:#E6DB74;"> &#39;Access-Control-Allow-Headers&#39;</span><span style="color:#E6DB74;"> &#39;DNT,Authorization,Accept,Origin,Keep-Alive,User-Agent,X-Mx-ReqToken,X-Data-Type,X-Auth-Token,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range&#39;</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    add_header</span><span style="color:#E6DB74;"> &#39;Access-Control-Expose-Headers&#39;</span><span style="color:#E6DB74;"> &#39;Content-Length,Content-Range&#39;</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#88846F;">    # 设置被嵌入(iframe)规则</span></span>
<span class="line"><span style="color:#88846F;">    # DENY 该页面不允许在frame中展示</span></span>
<span class="line"><span style="color:#88846F;">    # SAMEORIGIN 该页面可以在相同域名页面的frame中展示</span></span>
<span class="line"><span style="color:#88846F;">    # ALLOW-FROM uri 表示该页面可以在指定来源的frame中展示</span></span>
<span class="line"><span style="color:#A6E22E;">    add_header</span><span style="color:#E6DB74;"> X-Frame-Options</span><span style="color:#E6DB74;"> &quot;SAMEORIGIN&quot;</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#F8F8F2;">    </span></span>
<span class="line"><span style="color:#88846F;">    # 设置用于读取客户端请求体的缓冲器大小, 如果请求体大于缓冲区大小, 则会写入临时文件中</span></span>
<span class="line"><span style="color:#88846F;">    # syntax:	client_body_buffer_size size;</span></span>
<span class="line"><span style="color:#88846F;">    # default:	client_body_buffer_size 8k|16k;</span></span>
<span class="line"><span style="color:#88846F;">    # context:	http, server, location</span></span>
<span class="line"><span style="color:#A6E22E;">    client_body_buffer_size</span><span style="color:#E6DB74;"> 1024k</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">    </span></span>
<span class="line"><span style="color:#88846F;">    # 设置用于存储客户端请求体的历史文件, 在指定的目录下最多可以使用三极目录结构</span></span>
<span class="line"><span style="color:#88846F;">    # syntax:	client_body_temp_path path [level1 [level2 [level3]]];</span></span>
<span class="line"><span style="color:#88846F;">    # default:	client_body_temp_path client_body_temp;</span></span>
<span class="line"><span style="color:#88846F;">    # context:	http, server, location</span></span>
<span class="line"><span style="color:#A6E22E;">    client_body_temp_path</span><span style="color:#E6DB74;"> /opt/nginx/client_body_temp</span><span style="color:#AE81FF;"> 1</span><span style="color:#AE81FF;"> 2</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">    </span></span>
<span class="line"><span style="color:#88846F;">    # 设置客户端请求体的最大大小, 超过这个大小则返回413 Request Entity Too Large</span></span>
<span class="line"><span style="color:#88846F;">    # syntax:	client_max_body_size size;</span></span>
<span class="line"><span style="color:#88846F;">    # default:	client_max_body_size 1m;</span></span>
<span class="line"><span style="color:#88846F;">    # context:	http, server, location</span></span>
<span class="line"><span style="color:#A6E22E;">    client_max_body_size</span><span style="color:#E6DB74;"> 10m</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#88846F;">    # 设置用于读取客户端请求头的缓冲器大小, 如果请求头过长, 则分配large_client_header_buffers</span></span>
<span class="line"><span style="color:#88846F;">    # syntax:	client_header_buffer_size size;</span></span>
<span class="line"><span style="color:#88846F;">    # default:	client_header_buffer_size 1k;</span></span>
<span class="line"><span style="color:#88846F;">    # context:	http, server</span></span>
<span class="line"><span style="color:#A6E22E;">    client_header_buffer_size</span><span style="color:#E6DB74;"> 4k</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">    </span></span>
<span class="line"><span style="color:#88846F;">    # 设置用于读取大型客户端请求头的缓冲区数量和大小</span></span>
<span class="line"><span style="color:#88846F;">    # syntax:	large_client_header_buffers number size;</span></span>
<span class="line"><span style="color:#88846F;">    # default:	large_client_header_buffers 4 8k;</span></span>
<span class="line"><span style="color:#88846F;">    # context:	http, server</span></span>
<span class="line"><span style="color:#A6E22E;">    large_client_header_buffers</span><span style="color:#AE81FF;"> 4</span><span style="color:#E6DB74;"> 32k</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">    </span></span>
<span class="line"><span style="color:#88846F;">    # 设置读取客户端请求头的超时时间, 超时则返回408 Request Timed Out</span></span>
<span class="line"><span style="color:#88846F;">    # syntax:	client_header_timeout time;</span></span>
<span class="line"><span style="color:#88846F;">    # default:	client_header_timeout 60s;</span></span>
<span class="line"><span style="color:#88846F;">    # context:	http, server</span></span>
<span class="line"><span style="color:#A6E22E;">    client_header_timeout</span><span style="color:#E6DB74;"> 20s</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">    </span></span>
<span class="line"><span style="color:#88846F;">    # 设置keepalivec超时时间, 在一个活跃连接超过该时间后, 服务器和浏览器都会去关闭这个连接, 当然该参数是约束nginx服务器的, nginx也会按照规范把这个时间传给浏览器, 但每个浏览器对待keepalive的策略有可能是不同的</span></span>
<span class="line"><span style="color:#88846F;">    # syntax:	keepalive_timeout timeout [header_timeout];</span></span>
<span class="line"><span style="color:#88846F;">    # default:	keepalive_timeout 75s;</span></span>
<span class="line"><span style="color:#88846F;">    # context:	http, server, location</span></span>
<span class="line"><span style="color:#A6E22E;">    keepalive_timeout</span><span style="color:#E6DB74;"> 60s</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">    </span></span>
<span class="line"><span style="color:#88846F;">    # 设置使用proxy_hide_header和proxy_set_header指令时使用的最大hash表大小</span></span>
<span class="line"><span style="color:#88846F;">    # syntax:	proxy_headers_hash_max_size size;</span></span>
<span class="line"><span style="color:#88846F;">    # default:	proxy_headers_hash_max_size 512;</span></span>
<span class="line"><span style="color:#88846F;">    # context:	http, server, location</span></span>
<span class="line"><span style="color:#A6E22E;">    proxy_headers_hash_max_size</span><span style="color:#AE81FF;"> 512</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">    </span></span>
<span class="line"><span style="color:#88846F;">    # 设置使用proxy_hide_header和proxy_set_header指令时使用的hash表存储桶的大小</span></span>
<span class="line"><span style="color:#88846F;">    # syntax:	proxy_headers_hash_bucket_size size;</span></span>
<span class="line"><span style="color:#88846F;">    # default:	proxy_headers_hash_bucket_size 64;</span></span>
<span class="line"><span style="color:#88846F;">    # context:	http, server, location</span></span>
<span class="line"><span style="color:#A6E22E;">    proxy_headers_hash_bucket_size</span><span style="color:#AE81FF;"> 64</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">    </span></span>
<span class="line"><span style="color:#88846F;">    # 和后端代理服务器建立连接的超时时间</span></span>
<span class="line"><span style="color:#88846F;">    # syntax:	proxy_connect_timeout time;</span></span>
<span class="line"><span style="color:#88846F;">    # default:	proxy_connect_timeout 60s;</span></span>
<span class="line"><span style="color:#88846F;">    # context:	http, server, location</span></span>
<span class="line"><span style="color:#A6E22E;">    proxy_connect_timeout</span><span style="color:#E6DB74;"> 20s</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">    </span></span>
<span class="line"><span style="color:#88846F;">    # 设置根据uri匹配并且定位到对应的处理该请求的配置</span></span>
<span class="line"><span style="color:#88846F;">    # syntax:	location [ = | ~ | ~* | ^~ ] uri { ... }</span></span>
<span class="line"><span style="color:#88846F;">    # default:	—</span></span>
<span class="line"><span style="color:#88846F;">    # context:	server</span></span>
<span class="line"><span style="color:#A6E22E;">    location</span><span style="color:#E6DB74;"> /</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#F8F8F2;">    </span></span>
<span class="line"><span style="color:#88846F;">        # 修改或追加传递给后端服务节点的请求头</span></span>
<span class="line"><span style="color:#88846F;">        # syntax:	proxy_set_header field value;</span></span>
<span class="line"><span style="color:#88846F;">        # default:	proxy_set_header Host $proxy_host;</span></span>
<span class="line"><span style="color:#88846F;">        #           proxy_set_header Connection close;</span></span>
<span class="line"><span style="color:#88846F;">        # context:	http, server, location</span></span>
<span class="line"><span style="color:#F8F8F2;">        </span></span>
<span class="line"><span style="color:#88846F;">        # example01: 设置请求头host</span></span>
<span class="line"><span style="color:#A6E22E;">        proxy_set_header</span><span style="color:#E6DB74;"> Host</span><span style="color:#F8F8F2;"> $host;</span></span>
<span class="line"><span style="color:#88846F;">        # example02: 设置请求头X-Real-IP为$remote_addr</span></span>
<span class="line"><span style="color:#88846F;">        # $remote_addr是指访问nginx服务器的客户端, 并非最初的客户端ip地址</span></span>
<span class="line"><span style="color:#A6E22E;">        proxy_set_header</span><span style="color:#E6DB74;"> X-Real-IP</span><span style="color:#F8F8F2;"> $remote_addr;</span></span>
<span class="line"><span style="color:#88846F;">        # example03: 设置请求头X-Forwarded-For $proxy_add_x_forwarded_for</span></span>
<span class="line"><span style="color:#88846F;">        # $proxy_add_x_forwarded_for代表附加$remote_addr变量的客户端请求头X-Forwarded-For, 可以理解为$proxy_add_x_forwarded_for会依次记录$remote_addr值并以逗号分隔, 第一个值就是客户端ip</span></span>
<span class="line"><span style="color:#88846F;">        # 如果X-Forwarded-For字段没出现在客户端请求头中, $proxy_add_x_forwarded_for等同于$remote_addr</span></span>
<span class="line"><span style="color:#A6E22E;">        proxy_set_header</span><span style="color:#E6DB74;"> X-Forwarded-For</span><span style="color:#F8F8F2;"> $proxy_add_x_forwarded_for;</span></span>
<span class="line"><span style="color:#F8F8F2;">        </span></span>
<span class="line"><span style="color:#88846F;">        # 设置代理服务器地址端口和协议, 协议可以是http或者https, 地址可以使ip域名或者upstream中配置的服务器组</span></span>
<span class="line"><span style="color:#88846F;">        # syntax:	proxy_pass URL;</span></span>
<span class="line"><span style="color:#88846F;">        # default:	—</span></span>
<span class="line"><span style="color:#88846F;">        # context:	location</span></span>
<span class="line"><span style="color:#A6E22E;">        proxy_pass</span><span style="color:#E6DB74;"> http://www.example.com</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">    }</span></span>
<span class="line"></span>
<span class="line"><span style="color:#F8F8F2;">}</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br><span class="line-number">9</span><br><span class="line-number">10</span><br><span class="line-number">11</span><br><span class="line-number">12</span><br><span class="line-number">13</span><br><span class="line-number">14</span><br><span class="line-number">15</span><br><span class="line-number">16</span><br><span class="line-number">17</span><br><span class="line-number">18</span><br><span class="line-number">19</span><br><span class="line-number">20</span><br><span class="line-number">21</span><br><span class="line-number">22</span><br><span class="line-number">23</span><br><span class="line-number">24</span><br><span class="line-number">25</span><br><span class="line-number">26</span><br><span class="line-number">27</span><br><span class="line-number">28</span><br><span class="line-number">29</span><br><span class="line-number">30</span><br><span class="line-number">31</span><br><span class="line-number">32</span><br><span class="line-number">33</span><br><span class="line-number">34</span><br><span class="line-number">35</span><br><span class="line-number">36</span><br><span class="line-number">37</span><br><span class="line-number">38</span><br><span class="line-number">39</span><br><span class="line-number">40</span><br><span class="line-number">41</span><br><span class="line-number">42</span><br><span class="line-number">43</span><br><span class="line-number">44</span><br><span class="line-number">45</span><br><span class="line-number">46</span><br><span class="line-number">47</span><br><span class="line-number">48</span><br><span class="line-number">49</span><br><span class="line-number">50</span><br><span class="line-number">51</span><br><span class="line-number">52</span><br><span class="line-number">53</span><br><span class="line-number">54</span><br><span class="line-number">55</span><br><span class="line-number">56</span><br><span class="line-number">57</span><br><span class="line-number">58</span><br><span class="line-number">59</span><br><span class="line-number">60</span><br><span class="line-number">61</span><br><span class="line-number">62</span><br><span class="line-number">63</span><br><span class="line-number">64</span><br><span class="line-number">65</span><br><span class="line-number">66</span><br><span class="line-number">67</span><br><span class="line-number">68</span><br><span class="line-number">69</span><br><span class="line-number">70</span><br><span class="line-number">71</span><br><span class="line-number">72</span><br><span class="line-number">73</span><br><span class="line-number">74</span><br><span class="line-number">75</span><br><span class="line-number">76</span><br><span class="line-number">77</span><br><span class="line-number">78</span><br><span class="line-number">79</span><br><span class="line-number">80</span><br><span class="line-number">81</span><br><span class="line-number">82</span><br><span class="line-number">83</span><br><span class="line-number">84</span><br><span class="line-number">85</span><br><span class="line-number">86</span><br><span class="line-number">87</span><br><span class="line-number">88</span><br><span class="line-number">89</span><br><span class="line-number">90</span><br><span class="line-number">91</span><br><span class="line-number">92</span><br><span class="line-number">93</span><br><span class="line-number">94</span><br><span class="line-number">95</span><br><span class="line-number">96</span><br><span class="line-number">97</span><br><span class="line-number">98</span><br><span class="line-number">99</span><br><span class="line-number">100</span><br><span class="line-number">101</span><br><span class="line-number">102</span><br><span class="line-number">103</span><br><span class="line-number">104</span><br><span class="line-number">105</span><br><span class="line-number">106</span><br><span class="line-number">107</span><br><span class="line-number">108</span><br><span class="line-number">109</span><br><span class="line-number">110</span><br><span class="line-number">111</span><br><span class="line-number">112</span><br><span class="line-number">113</span><br><span class="line-number">114</span><br><span class="line-number">115</span><br><span class="line-number">116</span><br><span class="line-number">117</span><br><span class="line-number">118</span><br><span class="line-number">119</span><br><span class="line-number">120</span><br><span class="line-number">121</span><br><span class="line-number">122</span><br><span class="line-number">123</span><br><span class="line-number">124</span><br><span class="line-number">125</span><br><span class="line-number">126</span><br><span class="line-number">127</span><br><span class="line-number">128</span><br><span class="line-number">129</span><br><span class="line-number">130</span><br><span class="line-number">131</span><br><span class="line-number">132</span><br><span class="line-number">133</span><br><span class="line-number">134</span><br><span class="line-number">135</span><br><span class="line-number">136</span><br><span class="line-number">137</span><br><span class="line-number">138</span><br><span class="line-number">139</span><br><span class="line-number">140</span><br><span class="line-number">141</span><br><span class="line-number">142</span><br></div></div><h3 id="location匹配规则" tabindex="-1">location匹配规则 <a class="header-anchor" href="#location匹配规则" aria-label="Permalink to “location匹配规则”">​</a></h3><table tabindex="0"><thead><tr><th style="text-align:left;">表达式</th><th style="text-align:left;">模式</th><th style="text-align:left;">说明</th></tr></thead><tbody><tr><td style="text-align:left;">=</td><td style="text-align:left;">精确匹配</td><td style="text-align:left;">匹配成功,则终止其他location的匹配项,优先级最高</td></tr><tr><td style="text-align:left;">^~</td><td style="text-align:left;">前缀匹配</td><td style="text-align:left;">和顺序无关,按照命中长短来确定</td></tr><tr><td style="text-align:left;">~</td><td style="text-align:left;">正则匹配,区分大小写</td><td style="text-align:left;">和顺序有关系,匹配到了就停止</td></tr><tr><td style="text-align:left;">~*</td><td style="text-align:left;">正则匹配,不区分大小写</td><td style="text-align:left;">和顺序有关系,匹配到了就停止</td></tr><tr><td style="text-align:left;">/</td><td style="text-align:left;">普通匹配</td><td style="text-align:left;">和顺序无关,按照命中长短来确定,优先级最低</td></tr></tbody></table><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#88846F;"># syntax:	location [ = | ~ | ~* | ^~ ] uri { ... }</span></span>
<span class="line"><span style="color:#88846F;"># default:	—</span></span>
<span class="line"><span style="color:#88846F;"># context:	server</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br></div></div><h4 id="精确匹配" tabindex="-1">精确匹配 <a class="header-anchor" href="#精确匹配" aria-label="Permalink to “精确匹配”">​</a></h4><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#88846F;"># uri必须完全一致才能匹配到</span></span>
<span class="line"><span style="color:#A6E22E;">location</span><span style="color:#E6DB74;"> =</span><span style="color:#E6DB74;"> /abc</span><span style="color:#E6DB74;"> {}</span></span>
<span class="line"><span style="color:#88846F;"># 可以匹配到</span></span>
<span class="line"><span style="color:#A6E22E;">http://localhost/abc</span></span>
<span class="line"><span style="color:#A6E22E;">http://localhost/abc?key</span><span style="color:#E6DB74;">=1</span></span>
<span class="line"><span style="color:#88846F;"># 不能匹配到</span></span>
<span class="line"><span style="color:#A6E22E;">http://localhost/abc/</span></span>
<span class="line"><span style="color:#A6E22E;">http://localhost/abcd</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br></div></div><h4 id="前缀匹配" tabindex="-1">前缀匹配 <a class="header-anchor" href="#前缀匹配" aria-label="Permalink to “前缀匹配”">​</a></h4><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#88846F;"># uri必须以指定的前缀开头才能匹配到</span></span>
<span class="line"><span style="color:#A6E22E;">location</span><span style="color:#E6DB74;"> ^~</span><span style="color:#E6DB74;"> /static/</span><span style="color:#E6DB74;"> {}</span></span>
<span class="line"><span style="color:#88846F;"># 只有uri以/static/开头才能匹配到</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br></div></div><h4 id="正则匹配" tabindex="-1">正则匹配 <a class="header-anchor" href="#正则匹配" aria-label="Permalink to “正则匹配”">​</a></h4><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#88846F;"># uri需要符合正则表达式才能匹配到</span></span>
<span class="line"><span style="color:#A6E22E;">location</span><span style="color:#E6DB74;"> =</span><span style="color:#E6DB74;"> ~</span><span style="color:#FD971F;">*</span><span style="color:#AE81FF;"> \\.</span><span style="color:#F8F8F2;">(</span><span style="color:#A6E22E;">jpg</span><span style="color:#F92672;">|</span><span style="color:#A6E22E;">png</span><span style="color:#F92672;">|</span><span style="color:#A6E22E;">gif</span><span style="color:#F8F8F2;">)$  </span><span style="color:#E6DB74;">{}</span></span>
<span class="line"><span style="color:#88846F;"># uri中以.jpg .png .gif结尾的才能匹配到</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br></div></div><h4 id="通用匹配" tabindex="-1">通用匹配 <a class="header-anchor" href="#通用匹配" aria-label="Permalink to “通用匹配”">​</a></h4><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#88846F;"># 任何uri都能匹配到, 但是优先级最低</span></span>
<span class="line"><span style="color:#A6E22E;">location</span><span style="color:#E6DB74;"> /</span><span style="color:#E6DB74;"> {}</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br></div></div><h3 id="proxy-pass匹配规则" tabindex="-1">proxy_pass匹配规则 <a class="header-anchor" href="#proxy-pass匹配规则" aria-label="Permalink to “proxy_pass匹配规则”">​</a></h3><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#A6E22E;">location</span><span style="color:#E6DB74;"> /apis/v1</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#88846F;">    # 如果proxy_pass后面没有携带uri, 则客户端请求uri会完整的传递到后端服务器; 例如客户端的uri: /apis/v1/user, 传递给后端节点的uri: /apis/v1/user</span></span>
<span class="line"><span style="color:#A6E22E;">    proxy_pass</span><span style="color:#E6DB74;"> http://192.168.10.100:8080</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">}</span></span>
<span class="line"></span>
<span class="line"><span style="color:#A6E22E;">location</span><span style="color:#E6DB74;"> /apis/v1</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#88846F;">    # 如果proxy_pass后面携带了uri, 则客户端的请求uri则会将匹配到的部分替换为proxy_pass指令中配置的uri; 例如客户端的uri: /apis/v1/user, 传递给后端节点的uri: /api/v2/user</span></span>
<span class="line"><span style="color:#A6E22E;">    proxy_pass</span><span style="color:#E6DB74;"> http://192.168.10.100:8080/api/v2</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">}</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br><span class="line-number">9</span><br></div></div><h3 id="gzip压缩" tabindex="-1">gzip压缩 <a class="header-anchor" href="#gzip压缩" aria-label="Permalink to “gzip压缩”">​</a></h3><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#88846F;"># 是否开启gzip压缩指令</span></span>
<span class="line"><span style="color:#88846F;"># module:   ngx_http_gzip_module</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	gzip on | off;</span></span>
<span class="line"><span style="color:#88846F;"># default:	gzip off;</span></span>
<span class="line"><span style="color:#88846F;"># context:	http, server, location</span></span>
<span class="line"><span style="color:#A6E22E;">gzip</span><span style="color:#E6DB74;"> on</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#88846F;"># 设置需要进行gzip压缩的文件类型</span></span>
<span class="line"><span style="color:#88846F;"># module:   ngx_http_gzip_module</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	gzip_types mime-type ...;</span></span>
<span class="line"><span style="color:#88846F;"># default:	gzip_types text/html;</span></span>
<span class="line"><span style="color:#88846F;"># context:	http, server, location</span></span>
<span class="line"><span style="color:#A6E22E;">gzip_types</span><span style="color:#E6DB74;"> text/plain</span><span style="color:#E6DB74;"> text/css</span><span style="color:#E6DB74;"> application/javascript</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#88846F;"># 设置压缩等级, 范围为1到9, 数字越大压缩率越高, 但同时也会增加压缩的时间</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	gzip_comp_level level;</span></span>
<span class="line"><span style="color:#88846F;"># default:	gzip_comp_level 1;</span></span>
<span class="line"><span style="color:#88846F;"># context:	http, server, location</span></span>
<span class="line"><span style="color:#A6E22E;">gzip_comp_level</span><span style="color:#AE81FF;"> 2</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#88846F;"># 设置进行gzip压缩的最小文件大小, 只有当文件大小超过该值时, 才会进行gzip压缩</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	gzip_min_length length;</span></span>
<span class="line"><span style="color:#88846F;"># default:	gzip_min_length 20;</span></span>
<span class="line"><span style="color:#88846F;"># context:	http, server, location</span></span>
<span class="line"><span style="color:#A6E22E;">gzip_min_length</span><span style="color:#E6DB74;"> 1k</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#88846F;"># 设置最小的需要gzip压缩响应的http协议版本号</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	gzip_http_version 1.0 | 1.1;</span></span>
<span class="line"><span style="color:#88846F;"># default:	gzip_http_version 1.1;</span></span>
<span class="line"><span style="color:#88846F;"># context:	http, server, location</span></span>
<span class="line"><span style="color:#A6E22E;">gzip_http_version</span><span style="color:#AE81FF;"> 1.1</span><span style="color:#F8F8F2;">;</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br><span class="line-number">9</span><br><span class="line-number">10</span><br><span class="line-number">11</span><br><span class="line-number">12</span><br><span class="line-number">13</span><br><span class="line-number">14</span><br><span class="line-number">15</span><br><span class="line-number">16</span><br><span class="line-number">17</span><br><span class="line-number">18</span><br><span class="line-number">19</span><br><span class="line-number">20</span><br><span class="line-number">21</span><br><span class="line-number">22</span><br><span class="line-number">23</span><br><span class="line-number">24</span><br><span class="line-number">25</span><br><span class="line-number">26</span><br><span class="line-number">27</span><br><span class="line-number">28</span><br><span class="line-number">29</span><br><span class="line-number">30</span><br><span class="line-number">31</span><br></div></div><h3 id="日志配置" tabindex="-1">日志配置 <a class="header-anchor" href="#日志配置" aria-label="Permalink to “日志配置”">​</a></h3><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#88846F;"># 设置错误日志存储位置和日志等级</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	error_log file [level: debug | info | notice | warn | error | crit | alert];</span></span>
<span class="line"><span style="color:#88846F;"># default:	error_log logs/error.log error;</span></span>
<span class="line"><span style="color:#88846F;"># context:	main, http, mail, stream, server, location</span></span>
<span class="line"><span style="color:#A6E22E;">error_log</span><span style="color:#E6DB74;"> /var/log/nginx/error.log</span><span style="color:#E6DB74;"> notice</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#88846F;"># 日志格式, 基本包含了所有的字段 ,可以根据实际情况调整</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	log_format name [escape=default|json|none] string ...;</span></span>
<span class="line"><span style="color:#88846F;"># default:	log_format combined &quot;...&quot;;</span></span>
<span class="line"><span style="color:#88846F;"># context:	http</span></span>
<span class="line"><span style="color:#A6E22E;">log_format</span><span style="color:#E6DB74;"> main</span><span style="color:#E6DB74;"> &#39;$remote_addr - $remote_user [$time_local] &quot;$request&quot; &#39;</span></span>
<span class="line"><span style="color:#A6E22E;">                &#39;$status $body_bytes_sent &quot;$http_referer&quot; &#39;</span></span>
<span class="line"><span style="color:#A6E22E;">                &#39;&quot;$http_user_agent&quot; &quot;$http_x_forwarded_for&quot; &#39;</span></span>
<span class="line"><span style="color:#A6E22E;">                &#39;[$request_time $upstream_addr $upstream_connect_time $upstream_bytes_sent &#39;</span></span>
<span class="line"><span style="color:#A6E22E;">                &#39;$upstream_header_time $upstream_response_time $upstream_status $upstream_bytes_received $upstream_response_length $upstream_http_content_type]&#39;</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#88846F;"># 访问日志</span></span>
<span class="line"><span style="color:#88846F;"># Syntax:	access_log path [format [buffer=size] [gzip[=level]] [flush=time] [if=condition]];</span></span>
<span class="line"><span style="color:#88846F;"># 			access_log off;</span></span>
<span class="line"><span style="color:#88846F;"># Default:	access_log logs/access.log combined;</span></span>
<span class="line"><span style="color:#88846F;"># Context:	http, server, location</span></span>
<span class="line"><span style="color:#A6E22E;">access_log</span><span style="color:#E6DB74;"> /var/log/nginx/access.log</span><span style="color:#E6DB74;"> main</span><span style="color:#E6DB74;"> buffer=32k</span><span style="color:#F8F8F2;">;</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br><span class="line-number">9</span><br><span class="line-number">10</span><br><span class="line-number">11</span><br><span class="line-number">12</span><br><span class="line-number">13</span><br><span class="line-number">14</span><br><span class="line-number">15</span><br><span class="line-number">16</span><br><span class="line-number">17</span><br><span class="line-number">18</span><br><span class="line-number">19</span><br><span class="line-number">20</span><br><span class="line-number">21</span><br><span class="line-number">22</span><br></div></div><h3 id="nginx服务状态" tabindex="-1">nginx服务状态 <a class="header-anchor" href="#nginx服务状态" aria-label="Permalink to “nginx服务状态”">​</a></h3><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#88846F;"># 一般用于nginx连接的状态监控</span></span>
<span class="line"><span style="color:#88846F;"># module:   ngx_http_stub_status_module</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	stub_status;</span></span>
<span class="line"><span style="color:#88846F;"># default:	—</span></span>
<span class="line"><span style="color:#88846F;"># context:	server, location</span></span>
<span class="line"><span style="color:#A6E22E;">location</span><span style="color:#E6DB74;"> /ngx_status</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#A6E22E;">    stub_status</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">}</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br></div></div><table tabindex="0"><thead><tr><th style="text-align:left;">状态</th><th style="text-align:left;">说明</th></tr></thead><tbody><tr><td style="text-align:left;"><code>Active connections</code></td><td style="text-align:left;">当前活跃的客户端连接数, 包括等待的连接数</td></tr><tr><td style="text-align:left;"><code>accepts</code></td><td style="text-align:left;">已接收的客户端请求数</td></tr><tr><td style="text-align:left;"><code>handled</code></td><td style="text-align:left;">已处理的客户端请求数</td></tr><tr><td style="text-align:left;"><code>requests</code></td><td style="text-align:left;">客户端请求数</td></tr><tr><td style="text-align:left;"><code>Reading</code></td><td style="text-align:left;">正在读取客户端请求头的连接数</td></tr><tr><td style="text-align:left;"><code>Writing</code></td><td style="text-align:left;">正在回写响应的当前连接数</td></tr><tr><td style="text-align:left;"><code>Waiting</code></td><td style="text-align:left;">当前空闲的客户端连接数</td></tr></tbody></table><h3 id="访问控制" tabindex="-1">访问控制 <a class="header-anchor" href="#访问控制" aria-label="Permalink to “访问控制”">​</a></h3><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#88846F;"># 允许指定的网络地址访问</span></span>
<span class="line"><span style="color:#88846F;"># module:   ngx_http_access_module</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	allow address | CIDR | unix: | all;</span></span>
<span class="line"><span style="color:#88846F;"># default:	—</span></span>
<span class="line"><span style="color:#88846F;"># context:	http, server, location</span></span>
<span class="line"></span>
<span class="line"><span style="color:#88846F;"># 拒绝指定的网络地址访问</span></span>
<span class="line"><span style="color:#88846F;"># module:   ngx_http_access_module</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	deny address | CIDR | unix: | all;</span></span>
<span class="line"><span style="color:#88846F;"># default:	—</span></span>
<span class="line"><span style="color:#88846F;"># context:	http, server, location, limit_except</span></span>
<span class="line"></span>
<span class="line"><span style="color:#88846F;"># 只允许localhost和172.17.0.0/16段的地址访问</span></span>
<span class="line"><span style="color:#A6E22E;">location</span><span style="color:#E6DB74;"> /ngx_status</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#A6E22E;">    stub_status</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">    </span></span>
<span class="line"><span style="color:#A6E22E;">    allow</span><span style="color:#AE81FF;"> 127.0.0.1</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    allow</span><span style="color:#E6DB74;"> 172.17.0.0/16</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    deny</span><span style="color:#E6DB74;"> all</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">}</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br><span class="line-number">9</span><br><span class="line-number">10</span><br><span class="line-number">11</span><br><span class="line-number">12</span><br><span class="line-number">13</span><br><span class="line-number">14</span><br><span class="line-number">15</span><br><span class="line-number">16</span><br><span class="line-number">17</span><br><span class="line-number">18</span><br><span class="line-number">19</span><br><span class="line-number">20</span><br><span class="line-number">21</span><br></div></div><h3 id="限流" tabindex="-1">限流 <a class="header-anchor" href="#限流" aria-label="Permalink to “限流”">​</a></h3><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#88846F;"># 设置该limit_req共享区域参数</span></span>
<span class="line"><span style="color:#88846F;"># module:   ngx_http_limit_req_module</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	limit_req_zone key zone=name:size rate=rate [sync];</span></span>
<span class="line"><span style="color:#88846F;"># default:	—</span></span>
<span class="line"><span style="color:#88846F;"># context:	http</span></span>
<span class="line"><span style="color:#88846F;">## key 定义用于限制速率的依据,此处使用$binary_remote_addr是因为比$remote_addr占用更小的内存空间</span></span>
<span class="line"><span style="color:#88846F;">## zone 定义共享区域名称和大小, 1m大约能存储8000个$binary_remote_addr(64位)</span></span>
<span class="line"><span style="color:#88846F;">## rate 指定请求速率(r/s)或(r/m), 该示例中请求速率限制为每秒10个请求, 即每100毫秒1个, 超过该限制速率的请求会返回503</span></span>
<span class="line"><span style="color:#A6E22E;">limit_req_zone</span><span style="color:#F8F8F2;"> $binary_remote_addr </span><span style="color:#E6DB74;">zone=mylimit:10m</span><span style="color:#E6DB74;"> rate=10r/s</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#88846F;"># 设置limit_req的共享区域名称和突发请求大小</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	limit_req zone=name [burst=number] [nodelay | delay=number];</span></span>
<span class="line"><span style="color:#88846F;"># default:	—</span></span>
<span class="line"><span style="color:#88846F;"># context:	http, server, location</span></span>
<span class="line"><span style="color:#88846F;">## burst 表示客户端可以超过区域指定速率的请求数</span></span>
<span class="line"><span style="color:#88846F;">## nodelay 表示该请求会及时处理, 不会放到请求队列中</span></span>
<span class="line"><span style="color:#A6E22E;">server</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#A6E22E;">    location</span><span style="color:#E6DB74;"> /apis</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#A6E22E;">        limit_req</span><span style="color:#E6DB74;"> zone=mylimit</span><span style="color:#E6DB74;"> burst=</span><span style="color:#AE81FF;">5</span><span style="color:#E6DB74;"> nodelay</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">    }</span></span>
<span class="line"><span style="color:#F8F8F2;">    </span></span>
<span class="line"><span style="color:#88846F;"># 设置limit_conn共享区域参数</span></span>
<span class="line"><span style="color:#88846F;"># module:   ngx_http_limit_conn_module</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	limit_conn_zone key zone=name:size;</span></span>
<span class="line"><span style="color:#88846F;"># default:	—</span></span>
<span class="line"><span style="color:#88846F;"># context:	http</span></span>
<span class="line"><span style="color:#A6E22E;">limit_conn_zone</span><span style="color:#F8F8F2;"> $binary_remote_addr </span><span style="color:#E6DB74;">zone=addr:10m</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#88846F;"># 设置给定key的共享区域和允许的最大连接数</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	limit_conn zone number;</span></span>
<span class="line"><span style="color:#88846F;"># default:	—</span></span>
<span class="line"><span style="color:#88846F;"># context:	http, server, location</span></span>
<span class="line"><span style="color:#A6E22E;">server</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#A6E22E;">    location</span><span style="color:#E6DB74;"> /download/</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#A6E22E;">        limit_conn</span><span style="color:#E6DB74;"> addr</span><span style="color:#AE81FF;"> 2</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">    }</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br><span class="line-number">9</span><br><span class="line-number">10</span><br><span class="line-number">11</span><br><span class="line-number">12</span><br><span class="line-number">13</span><br><span class="line-number">14</span><br><span class="line-number">15</span><br><span class="line-number">16</span><br><span class="line-number">17</span><br><span class="line-number">18</span><br><span class="line-number">19</span><br><span class="line-number">20</span><br><span class="line-number">21</span><br><span class="line-number">22</span><br><span class="line-number">23</span><br><span class="line-number">24</span><br><span class="line-number">25</span><br><span class="line-number">26</span><br><span class="line-number">27</span><br><span class="line-number">28</span><br><span class="line-number">29</span><br><span class="line-number">30</span><br><span class="line-number">31</span><br><span class="line-number">32</span><br><span class="line-number">33</span><br><span class="line-number">34</span><br><span class="line-number">35</span><br><span class="line-number">36</span><br></div></div><h3 id="模拟跨域" tabindex="-1">模拟跨域 <a class="header-anchor" href="#模拟跨域" aria-label="Permalink to “模拟跨域”">​</a></h3><p>step01 快速启动nginx</p><div class="language-yaml line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">yaml</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#F92672;">version</span><span style="color:#F8F8F2;">: </span><span style="color:#E6DB74;">&quot;3&quot;</span></span>
<span class="line"><span style="color:#F92672;">services</span><span style="color:#F8F8F2;">:</span></span>
<span class="line"><span style="color:#F92672;">  nginx</span><span style="color:#F8F8F2;">:</span></span>
<span class="line"><span style="color:#F92672;">    hostname</span><span style="color:#F8F8F2;">: </span><span style="color:#E6DB74;">nginx</span></span>
<span class="line"><span style="color:#F92672;">    image</span><span style="color:#F8F8F2;">: </span><span style="color:#E6DB74;">nginx:alpine</span></span>
<span class="line"><span style="color:#F92672;">    container_name</span><span style="color:#F8F8F2;">: </span><span style="color:#E6DB74;">nginx</span></span>
<span class="line"><span style="color:#F92672;">    volumes</span><span style="color:#F8F8F2;">:</span></span>
<span class="line"><span style="color:#F8F8F2;">      - </span><span style="color:#E6DB74;">./conf:/etc/nginx</span></span>
<span class="line"><span style="color:#F92672;">    ports</span><span style="color:#F8F8F2;">:</span></span>
<span class="line"><span style="color:#F8F8F2;">      - </span><span style="color:#E6DB74;">&quot;10000:10000&quot;</span></span>
<span class="line"><span style="color:#F8F8F2;">      - </span><span style="color:#E6DB74;">&quot;9000:9000&quot;</span></span>
<span class="line"><span style="color:#F8F8F2;">      - </span><span style="color:#E6DB74;">&quot;8000:8000&quot;</span></span>
<span class="line"><span style="color:#F92672;">    logging</span><span style="color:#F8F8F2;">:</span></span>
<span class="line"><span style="color:#F92672;">      driver</span><span style="color:#F8F8F2;">: </span><span style="color:#E6DB74;">json-file</span></span>
<span class="line"><span style="color:#F92672;">      options</span><span style="color:#F8F8F2;">:</span></span>
<span class="line"><span style="color:#F92672;">        max-size</span><span style="color:#F8F8F2;">: </span><span style="color:#E6DB74;">100m</span></span>
<span class="line"><span style="color:#F92672;">        max-file</span><span style="color:#F8F8F2;">: </span><span style="color:#E6DB74;">&quot;3&quot;</span></span>
<span class="line"><span style="color:#F92672;">    restart</span><span style="color:#F8F8F2;">: </span><span style="color:#E6DB74;">on-failure</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br><span class="line-number">9</span><br><span class="line-number">10</span><br><span class="line-number">11</span><br><span class="line-number">12</span><br><span class="line-number">13</span><br><span class="line-number">14</span><br><span class="line-number">15</span><br><span class="line-number">16</span><br><span class="line-number">17</span><br><span class="line-number">18</span><br></div></div><p>step02 <code>/etc/nginx/conf.d/default.conf</code></p><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#A6E22E;">server</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#A6E22E;">    listen</span><span style="color:#AE81FF;">       10000</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    server_name</span><span style="color:#E6DB74;">  localhost</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    location</span><span style="color:#E6DB74;"> /</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#A6E22E;">        root</span><span style="color:#E6DB74;">   /etc/nginx/html</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">        index</span><span style="color:#E6DB74;">  index.html</span><span style="color:#E6DB74;"> index.htm</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">    }</span></span>
<span class="line"><span style="color:#F8F8F2;">}</span></span>
<span class="line"></span>
<span class="line"><span style="color:#A6E22E;">server</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#A6E22E;">    listen</span><span style="color:#AE81FF;">       9000</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    server_name</span><span style="color:#E6DB74;">  localhost</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    location</span><span style="color:#E6DB74;"> /</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#A6E22E;">        proxy_pass</span><span style="color:#E6DB74;"> http://localhost:8000</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">    }</span></span>
<span class="line"><span style="color:#F8F8F2;">}</span></span>
<span class="line"></span>
<span class="line"><span style="color:#A6E22E;">server</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#A6E22E;">    listen</span><span style="color:#AE81FF;">       8000</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    server_name</span><span style="color:#E6DB74;">  localhost</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    location</span><span style="color:#E6DB74;"> /</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#A6E22E;">        default_type</span><span style="color:#E6DB74;"> application/json</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F92672;">        return</span><span style="color:#AE81FF;"> 200</span><span style="color:#E6DB74;"> &#39;{&quot;code&quot;:&quot;0000&quot;,&quot;msg&quot;:&quot;success&quot;}&#39;</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">    }</span></span>
<span class="line"><span style="color:#F8F8F2;">}</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br><span class="line-number">9</span><br><span class="line-number">10</span><br><span class="line-number">11</span><br><span class="line-number">12</span><br><span class="line-number">13</span><br><span class="line-number">14</span><br><span class="line-number">15</span><br><span class="line-number">16</span><br><span class="line-number">17</span><br><span class="line-number">18</span><br><span class="line-number">19</span><br><span class="line-number">20</span><br><span class="line-number">21</span><br><span class="line-number">22</span><br><span class="line-number">23</span><br><span class="line-number">24</span><br><span class="line-number">25</span><br></div></div><p>step03 <code>/etc/nginx/html/index.html</code></p><div class="language-html line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">html</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#F8F8F2;">&lt;</span><span style="color:#F92672;">html</span><span style="color:#F8F8F2;">&gt;</span></span>
<span class="line"><span style="color:#F8F8F2;">&lt;</span><span style="color:#F92672;">div</span><span style="color:#F8F8F2;">&gt;CORS&lt;/</span><span style="color:#F92672;">div</span><span style="color:#F8F8F2;">&gt;</span></span>
<span class="line"><span style="color:#F8F8F2;">&lt;</span><span style="color:#F92672;">script</span><span style="color:#F8F8F2;">&gt;</span></span>
<span class="line"><span style="color:#A6E22E;">fetch</span><span style="color:#F8F8F2;">(</span><span style="color:#E6DB74;">&quot;http://192.168.10.11:9000/&quot;</span><span style="color:#F8F8F2;">, {</span></span>
<span class="line"><span style="color:#E6DB74;">  &quot;headers&quot;</span><span style="color:#F8F8F2;">: {</span></span>
<span class="line"><span style="color:#E6DB74;">    &quot;accept&quot;</span><span style="color:#F8F8F2;">: </span><span style="color:#E6DB74;">&quot;application/json&quot;</span><span style="color:#F8F8F2;">,</span></span>
<span class="line"><span style="color:#F8F8F2;">  },</span></span>
<span class="line"><span style="color:#E6DB74;">  &quot;body&quot;</span><span style="color:#F8F8F2;">: </span><span style="color:#AE81FF;">null</span><span style="color:#F8F8F2;">,</span></span>
<span class="line"><span style="color:#E6DB74;">  &quot;method&quot;</span><span style="color:#F8F8F2;">: </span><span style="color:#E6DB74;">&quot;GET&quot;</span><span style="color:#F8F8F2;">,</span></span>
<span class="line"><span style="color:#F8F8F2;">}).</span><span style="color:#A6E22E;">then</span><span style="color:#F8F8F2;">(</span><span style="color:#FD971F;font-style:italic;">res</span><span style="color:#66D9EF;font-style:italic;"> =&gt;</span><span style="color:#F8F8F2;"> {</span></span>
<span class="line"><span style="color:#F8F8F2;">   console.</span><span style="color:#A6E22E;">log</span><span style="color:#F8F8F2;">(</span><span style="color:#E6DB74;">&quot;res: &quot;</span><span style="color:#F8F8F2;">, res)</span></span>
<span class="line"><span style="color:#F8F8F2;">}).</span><span style="color:#A6E22E;">catch</span><span style="color:#F8F8F2;">(</span><span style="color:#FD971F;font-style:italic;">err</span><span style="color:#66D9EF;font-style:italic;"> =&gt;</span><span style="color:#F8F8F2;"> {</span></span>
<span class="line"><span style="color:#F8F8F2;">   console.</span><span style="color:#A6E22E;">log</span><span style="color:#F8F8F2;">(</span><span style="color:#E6DB74;">&quot;err: &quot;</span><span style="color:#F8F8F2;">, err)</span></span>
<span class="line"><span style="color:#F8F8F2;">});</span></span>
<span class="line"><span style="color:#F8F8F2;">&lt;/</span><span style="color:#F92672;">script</span><span style="color:#F8F8F2;">&gt;</span></span>
<span class="line"><span style="color:#F8F8F2;">&lt;/</span><span style="color:#F92672;">html</span><span style="color:#F8F8F2;">&gt;</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br><span class="line-number">9</span><br><span class="line-number">10</span><br><span class="line-number">11</span><br><span class="line-number">12</span><br><span class="line-number">13</span><br><span class="line-number">14</span><br><span class="line-number">15</span><br><span class="line-number">16</span><br></div></div><p>step04 浏览器测试访问<code>http://192.168.10.11:10000</code></p><h3 id="处理跨域" tabindex="-1">处理跨域 <a class="header-anchor" href="#处理跨域" aria-label="Permalink to “处理跨域”">​</a></h3><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#A6E22E;">server</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#A6E22E;">    listen</span><span style="color:#AE81FF;">       9000</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    server_name</span><span style="color:#E6DB74;">  localhost</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    location</span><span style="color:#E6DB74;"> /</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#88846F;">        # add_header &#39;Access-Control-Allow-Origin&#39; &#39;*&#39; always;</span></span>
<span class="line highlighted"><span style="color:#A6E22E;">        add_header</span><span style="color:#E6DB74;"> &#39;Access-Control-Allow-Origin&#39;</span><span style="color:#F8F8F2;"> $http_origin </span><span style="color:#E6DB74;">always</span><span style="color:#F8F8F2;">;</span></span>
<span class="line highlighted"><span style="color:#A6E22E;">        add_header</span><span style="color:#E6DB74;"> &#39;Access-Control-Allow-Credentials&#39;</span><span style="color:#E6DB74;"> &#39;true&#39;</span><span style="color:#F8F8F2;">;</span></span>
<span class="line highlighted"><span style="color:#A6E22E;">        add_header</span><span style="color:#E6DB74;"> &#39;Access-Control-Allow-Methods&#39;</span><span style="color:#E6DB74;"> &#39;GET, POST, OPTIONS&#39;</span><span style="color:#F8F8F2;">;</span></span>
<span class="line highlighted"><span style="color:#A6E22E;">        add_header</span><span style="color:#E6DB74;"> &#39;Access-Control-Allow-Headers&#39;</span><span style="color:#E6DB74;"> &#39;DNT,Authorization,Accept,Origin,Keep-Alive,User-Agent,X-Mx-ReqToken,X-Data-Type,X-Auth-Token,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range&#39;</span><span style="color:#F8F8F2;">;</span></span>
<span class="line highlighted"><span style="color:#A6E22E;">        add_header</span><span style="color:#E6DB74;"> &#39;Access-Control-Expose-Headers&#39;</span><span style="color:#E6DB74;"> &#39;Content-Length,Content-Range&#39;</span><span style="color:#F8F8F2;">;</span></span>
<span class="line highlighted"><wbr></span>
<span class="line highlighted"><span style="color:#F92672;">        if</span><span style="color:#F8F8F2;"> ($request_method = </span><span style="color:#E6DB74;">&#39;OPTIONS&#39;</span><span style="color:#F8F8F2;">) {</span></span>
<span class="line highlighted"><span style="color:#F92672;">                return</span><span style="color:#AE81FF;"> 204</span><span style="color:#F8F8F2;">;</span></span>
<span class="line highlighted"><span style="color:#F8F8F2;">        }</span></span>
<span class="line highlighted"><wbr></span>
<span class="line highlighted"><span style="color:#A6E22E;">        proxy_set_header</span><span style="color:#E6DB74;"> origin</span><span style="color:#E6DB74;"> &#39;&#39;</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">        proxy_pass</span><span style="color:#E6DB74;"> http://192.168.10.11:8000</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">    }</span></span>
<span class="line"><span style="color:#F8F8F2;">}</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br><span class="line-number">9</span><br><span class="line-number">10</span><br><span class="line-number">11</span><br><span class="line-number">12</span><br><span class="line-number">13</span><br><span class="line-number">14</span><br><span class="line-number">15</span><br><span class="line-number">16</span><br><span class="line-number">17</span><br><span class="line-number">18</span><br><span class="line-number">19</span><br></div></div><h3 id="动态路由" tabindex="-1">动态路由 <a class="header-anchor" href="#动态路由" aria-label="Permalink to “动态路由”">​</a></h3><p>⚡例如<code>vue</code>项目中使用动态路由，通常配置在页面刷新后会获取不到资源</p><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#A6E22E;">location</span><span style="color:#E6DB74;"> /</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#A6E22E;">    root</span><span style="color:#E6DB74;"> /usr/share/nginx/html/dist</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    index</span><span style="color:#E6DB74;"> index.html</span><span style="color:#E6DB74;"> index.htm</span><span style="color:#F8F8F2;">;</span></span>
<span class="line highlighted"><span style="color:#A6E22E;">    try_files</span><span style="color:#F8F8F2;"> $uri $uri</span><span style="color:#E6DB74;">/</span><span style="color:#E6DB74;"> /index.html</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">}</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br></div></div><h2 id="stream四层代理" tabindex="-1">stream四层代理 <a class="header-anchor" href="#stream四层代理" aria-label="Permalink to “stream四层代理”">​</a></h2><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#88846F;"># 主要用于四层代理的配置，比如数据库等</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	stream { ... }</span></span>
<span class="line"><span style="color:#88846F;"># default:	—</span></span>
<span class="line"><span style="color:#88846F;"># context:	main</span></span>
<span class="line"><span style="color:#A6E22E;">stream</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#88846F;">    # 是否开启tcp_nodelay,表示收到数据包后尽快发送出去</span></span>
<span class="line"><span style="color:#88846F;">    # syntax:	tcp_nodelay on | off;</span></span>
<span class="line"><span style="color:#88846F;">    # default:	</span></span>
<span class="line"><span style="color:#88846F;">    # tcp_nodelay on;</span></span>
<span class="line"><span style="color:#88846F;">    # Context:	stream, server</span></span>
<span class="line"><span style="color:#A6E22E;">    tcp_nodelay</span><span style="color:#E6DB74;"> on</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">}</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br><span class="line-number">9</span><br><span class="line-number">10</span><br><span class="line-number">11</span><br><span class="line-number">12</span><br></div></div><h3 id="upstream-1" tabindex="-1">upstream <a class="header-anchor" href="#upstream-1" aria-label="Permalink to “upstream”">​</a></h3><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#88846F;"># 用于定义可以由proxy_pass指令引用的服务器组, 可以指定服务节点的地址和相关的参数, 服务器地址可以是带端口的域名或者ip地址、unix套接字路径, 参数可以设置服务权重、健康检查等</span></span>
<span class="line"><span style="color:#88846F;"># module: ngx_stream_upstream_module</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	server address [parameters];</span></span>
<span class="line"><span style="color:#88846F;"># default:	—</span></span>
<span class="line"><span style="color:#88846F;"># context:	stream</span></span>
<span class="line"><span style="color:#A6E22E;">upstream</span><span style="color:#E6DB74;"> backend</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#A6E22E;">    server</span><span style="color:#E6DB74;"> db1.example.com:13306</span><span style="color:#E6DB74;"> weight=</span><span style="color:#AE81FF;">2</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    server</span><span style="color:#E6DB74;"> 127.0.0.1:13306</span><span style="color:#E6DB74;"> max_fails=</span><span style="color:#AE81FF;">3</span><span style="color:#E6DB74;"> fail_timeout=30s</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    server</span><span style="color:#E6DB74;"> unix:/tmp/backend2</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    server</span><span style="color:#E6DB74;"> db2.example.com:13306</span><span style="color:#E6DB74;">  backup</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">}</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br><span class="line-number">9</span><br><span class="line-number">10</span><br><span class="line-number">11</span><br></div></div><h3 id="server-1" tabindex="-1">server <a class="header-anchor" href="#server-1" aria-label="Permalink to “server”">​</a></h3><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#A6E22E;">server</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#88846F;">    # 指定监听的端口协议等</span></span>
<span class="line"><span style="color:#88846F;">    # syntax:	listen address:port [ssl] [udp] [proxy_protocol] [fastopen=number] [backlog=number] [rcvbuf=size] [sndbuf=size] [bind] [ipv6only=on|off] [reuseport] [so_keepalive=on|off|[keepidle]:[keepintvl]:[keepcnt]];</span></span>
<span class="line"><span style="color:#88846F;">    # default:	—</span></span>
<span class="line"><span style="color:#88846F;">    # context:	server</span></span>
<span class="line"><span style="color:#A6E22E;">    listen</span><span style="color:#AE81FF;"> 60001</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">    </span></span>
<span class="line"><span style="color:#88846F;">    # 和后端服务建立连接的超时时间</span></span>
<span class="line"><span style="color:#88846F;">    # module:   ngx_stream_proxy_module</span></span>
<span class="line"><span style="color:#88846F;">    # syntax:	proxy_connect_timeout time;</span></span>
<span class="line"><span style="color:#88846F;">    # default:	proxy_connect_timeout 60s;</span></span>
<span class="line"><span style="color:#88846F;">    # context:	stream, server</span></span>
<span class="line"><span style="color:#A6E22E;">    proxy_connect_timeout</span><span style="color:#E6DB74;"> 1s</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">    </span></span>
<span class="line"><span style="color:#88846F;">    # 设置客户端或代理服务器上两个连续读取或写入操作之间的超时时间, 如果在此时间内未传输任何数据, 连接将h会关闭。</span></span>
<span class="line"><span style="color:#88846F;">    # syntax:	proxy_timeout timeout;</span></span>
<span class="line"><span style="color:#88846F;">    # default:	proxy_timeout 10m;</span></span>
<span class="line"><span style="color:#88846F;">    # context:	stream, server</span></span>
<span class="line"><span style="color:#A6E22E;">    proxy_timeout</span><span style="color:#E6DB74;"> 30s</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">    </span></span>
<span class="line"><span style="color:#88846F;">    # </span></span>
<span class="line"><span style="color:#88846F;">    # syntax:	proxy_pass address;</span></span>
<span class="line"><span style="color:#88846F;">    # default:	—</span></span>
<span class="line"><span style="color:#88846F;">    # context:	server</span></span>
<span class="line"><span style="color:#A6E22E;">    proxy_pass</span><span style="color:#E6DB74;"> backend</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">}</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br><span class="line-number">9</span><br><span class="line-number">10</span><br><span class="line-number">11</span><br><span class="line-number">12</span><br><span class="line-number">13</span><br><span class="line-number">14</span><br><span class="line-number">15</span><br><span class="line-number">16</span><br><span class="line-number">17</span><br><span class="line-number">18</span><br><span class="line-number">19</span><br><span class="line-number">20</span><br><span class="line-number">21</span><br><span class="line-number">22</span><br><span class="line-number">23</span><br><span class="line-number">24</span><br><span class="line-number">25</span><br><span class="line-number">26</span><br><span class="line-number">27</span><br></div></div><h3 id="日志配置-1" tabindex="-1">日志配置 <a class="header-anchor" href="#日志配置-1" aria-label="Permalink to “日志配置”">​</a></h3><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#88846F;"># 设置四层代理的日志格式</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	log_format name [escape=default|json|none] string ...;</span></span>
<span class="line"><span style="color:#88846F;"># default:	—</span></span>
<span class="line"><span style="color:#88846F;"># context:	stream</span></span>
<span class="line"><span style="color:#A6E22E;">log_format</span><span style="color:#E6DB74;"> l4log</span><span style="color:#E6DB74;"> &#39;$remote_addr [$time_local] &#39;</span></span>
<span class="line"><span style="color:#A6E22E;">                 &#39;$protocol $status $bytes_sent $bytes_received &#39;</span></span>
<span class="line"><span style="color:#A6E22E;">                 &#39;$session_time &quot;$upstream_addr&quot; &#39;</span></span>
<span class="line"><span style="color:#A6E22E;">                 &#39;&quot;$upstream_bytes_sent&quot; &quot;$upstream_bytes_received&quot; &quot;$upstream_connect_time&quot;&#39;</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"></span>
<span class="line"><span style="color:#88846F;"># Syntax:	access_log path format [buffer=size] [gzip[=level]] [flush=time] [if=condition];</span></span>
<span class="line"><span style="color:#88846F;">#        	access_log off;</span></span>
<span class="line"><span style="color:#88846F;"># default:	access_log off;</span></span>
<span class="line"><span style="color:#88846F;"># context:	stream, server</span></span>
<span class="line"><span style="color:#A6E22E;">access_log</span><span style="color:#E6DB74;"> /var/log/nginx/access.log</span><span style="color:#E6DB74;"> l4log</span><span style="color:#F8F8F2;">;</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br><span class="line-number">9</span><br><span class="line-number">10</span><br><span class="line-number">11</span><br><span class="line-number">12</span><br><span class="line-number">13</span><br><span class="line-number">14</span><br></div></div><h2 id="负载均衡算法" tabindex="-1">负载均衡算法 <a class="header-anchor" href="#负载均衡算法" aria-label="Permalink to “负载均衡算法”">​</a></h2><h3 id="轮询" tabindex="-1">轮询 <a class="header-anchor" href="#轮询" aria-label="Permalink to “轮询”">​</a></h3><p>轮询(Round Robin): 默认算法,请求会依次转发到后端服务节点</p><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#88846F;"># module:   ngx_http_upstream_module</span></span>
<span class="line"><span style="color:#88846F;"># context:	upstream</span></span>
<span class="line"><span style="color:#A6E22E;">upstream</span><span style="color:#E6DB74;"> backend</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#A6E22E;">    server</span><span style="color:#E6DB74;"> 192.168.10.100:8080</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    server</span><span style="color:#E6DB74;"> 192.168.10.101:8080</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">}</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br></div></div><h3 id="加权轮询" tabindex="-1">加权轮询 <a class="header-anchor" href="#加权轮询" aria-label="Permalink to “加权轮询”">​</a></h3><p>加权轮询(Weight): 即weight越大, 分配到的连接越多</p><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#88846F;"># module:   ngx_http_upstream_module</span></span>
<span class="line"><span style="color:#88846F;"># context:	upstream</span></span>
<span class="line"><span style="color:#A6E22E;">upstream</span><span style="color:#E6DB74;"> backend</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#A6E22E;">    server</span><span style="color:#E6DB74;"> 192.168.10.100:8080</span><span style="color:#E6DB74;"> weight=</span><span style="color:#AE81FF;">4</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    server</span><span style="color:#E6DB74;"> 192.168.10.101:8080</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">}</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br></div></div><h3 id="最少连接" tabindex="-1">最少连接 <a class="header-anchor" href="#最少连接" aria-label="Permalink to “最少连接”">​</a></h3><p>最少连接算法(Least Connections): 优先将请求转发到连接数少的服务节点</p><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#88846F;"># module:   ngx_http_upstream_module</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	least_conn;</span></span>
<span class="line"><span style="color:#88846F;"># default:	—</span></span>
<span class="line"><span style="color:#88846F;"># context:	upstream</span></span>
<span class="line"><span style="color:#A6E22E;">upstream</span><span style="color:#E6DB74;"> backend</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#A6E22E;">    least_conn</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    server</span><span style="color:#E6DB74;"> 192.168.10.100:8080</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    server</span><span style="color:#E6DB74;"> 192.168.10.101:8080</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">}</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br><span class="line-number">9</span><br></div></div><h3 id="哈希" tabindex="-1">哈希 <a class="header-anchor" href="#哈希" aria-label="Permalink to “哈希”">​</a></h3><p>哈希(hash): 基于hash的调度算法, 计算key的哈希值, 根据计算结果将请求转发至特定的服务节点</p><p>算法:<code>hash(key) % node_counts = index</code></p><p>值得注意的是当node_counts(节点数量)发生变化时, index(服务节点索引)也会发生变化</p><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#88846F;"># module:   ngx_http_upstream_module</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	hash key;</span></span>
<span class="line"><span style="color:#88846F;"># default:	—</span></span>
<span class="line"><span style="color:#88846F;"># context:	upstream</span></span>
<span class="line"><span style="color:#A6E22E;">upstream</span><span style="color:#E6DB74;"> backend</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#66D9EF;">    hash</span><span style="color:#F8F8F2;"> $request_uri;</span></span>
<span class="line"><span style="color:#A6E22E;">    server</span><span style="color:#E6DB74;"> 192.168.10.100:8080</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    server</span><span style="color:#E6DB74;"> 192.168.10.101:8080</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">}</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br><span class="line-number">9</span><br></div></div><h3 id="ip哈希" tabindex="-1">IP哈希 <a class="header-anchor" href="#ip哈希" aria-label="Permalink to “IP哈希”">​</a></h3><p>IP哈希(IP Hash): 基于请求的客户端ip的hash值, 确保来自同一客户端的请求将始终转发到同一服务节点, 一般用于会话保持</p><p>算法:<code>hash(client_ip) % node_counts = index</code></p><p>值得注意的是当node_counts(节点数量)发生变化时, index(服务节点索引)也会发生变化</p><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#88846F;"># module:   ngx_http_upstream_module</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	ip_hash;</span></span>
<span class="line"><span style="color:#88846F;"># default:	—</span></span>
<span class="line"><span style="color:#88846F;"># context:	upstream</span></span>
<span class="line"><span style="color:#A6E22E;">upstream</span><span style="color:#E6DB74;"> backend</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#A6E22E;">    ip_hash</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    server</span><span style="color:#E6DB74;"> 192.168.10.100:8080</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    server</span><span style="color:#E6DB74;"> 192.168.10.101:8080</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">}</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br><span class="line-number">9</span><br></div></div><h3 id="一致性哈希" tabindex="-1">一致性哈希 <a class="header-anchor" href="#一致性哈希" aria-label="Permalink to “一致性哈希”">​</a></h3><p>一致性哈希(Consistent Hash): 在上述哈希算法中, 如果有大量的请求调度到某一服务节点, 而某些服务节点不可用或者新增服务节点导致服务节点数量变化, 则该算法会重新计算结果, 从而造成大量的请求被转移其他节点处理, 则会话失效, 需要客户端重新建立回话保持; 为解决上述问题, 就需要使用一致性哈希</p><div class="language-shell line-numbers-mode"><button title="Copy Code" class="copy"></button><span class="lang">shell</span><pre class="shiki monokai" style="background-color:#272822;color:#F8F8F2;" tabindex="0" dir="ltr"><code><span class="line"><span style="color:#88846F;"># module:   ngx_http_upstream_module</span></span>
<span class="line"><span style="color:#88846F;"># syntax:	hash key consistent;</span></span>
<span class="line"><span style="color:#88846F;"># default:	—</span></span>
<span class="line"><span style="color:#88846F;"># context:	upstream</span></span>
<span class="line"><span style="color:#A6E22E;">upstream</span><span style="color:#E6DB74;"> backend01</span><span style="color:#E6DB74;"> {</span></span>
<span class="line"><span style="color:#66D9EF;">    hash</span><span style="color:#F8F8F2;"> $remote_addr </span><span style="color:#E6DB74;">consistent</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    server</span><span style="color:#E6DB74;"> 192.168.10.100:8080</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#A6E22E;">    server</span><span style="color:#E6DB74;"> 192.168.10.101:8080</span><span style="color:#F8F8F2;">;</span></span>
<span class="line"><span style="color:#F8F8F2;">}</span></span></code></pre><div class="line-numbers-wrapper" aria-hidden="true"><span class="line-number">1</span><br><span class="line-number">2</span><br><span class="line-number">3</span><br><span class="line-number">4</span><br><span class="line-number">5</span><br><span class="line-number">6</span><br><span class="line-number">7</span><br><span class="line-number">8</span><br><span class="line-number">9</span><br></div></div>`,83)])])}const F=n(p,[["render",r]]);export{u as __pageData,F as default};
